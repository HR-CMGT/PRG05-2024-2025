#!/bin/bash

#make sure package index is up-to-date
sudo apt update

#remove apache
sudo systemctl stop apache2
sudo apt purge apache2 apache2-utils apache2-bin apache2.2-common -y
sudo apt autoremove -y
sudo rm -rf /etc/apache2
sudo service stop apache2
sudo apt -y remove apache2*
sudo apt -y autoremove
sudo rm /var/www/html/index.html

#install all relevant tools
sudo apt -y install curl wget gpg gnupg2 lsb-release software-properties-common ca-certificates apt-transport-https zip unzip tar git build-essential sqlite3 nginx htop nano net-tools tmux

#install & enable ssh (not relevant for HR VM as its already installed)
#sudo apt -y install openssh-server
#sudo systemctl enable ssh
#sudo systemctl start ssh

#add your user to the www-data group
current_user=$(whoami)
sudo usermod -a -G www-data "$current_user"

#install certbot (via snap)
sudo snap install core
sudo snap refresh core
sudo snap install --classic certbot
sudo ln -s /snap/bin/certbot /usr/bin/certbot

#add repository for latest php versions
sudo add-apt-repository ppa:ondrej/php -y

#install php8.3 (8.4 is released at 21-11-2024 but you've developed Laravel with 8.3 in mind)
sudo apt -y install php8.3

#install all php extensions required
sudo apt -y install php8.3-{cli,pdo,zip,gd,mbstring,curl,xml,bcmath,common,fpm,sqlite3,exif,intl,opcache,tokenizer}

#install composer
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
php -r "if (hash_file('sha384', 'composer-setup.php') === 'dac665fdc30fdd8ec78b38b9800061b4150413ff2e3b6f88543c636f7cd84f6db9189d43a81e5503cda447da73c7e5b6') { echo 'Installer verified'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
php composer-setup.php
php -r "unlink('composer-setup.php');"

#move composer to actual location
sudo mv composer.phar /usr/local/bin/composer

#generate ssh key needed for git checkout
ssh-keygen -q -t rsa -N '' -f ~/.ssh/id_rsa <<<y >/dev/null 2>&1

#install node/npm via nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
source ~/.bashrc
command -v nvm
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion
nvm install --lts

#inform user of final result
echo "All tools are installed, check any errors above in the logs"
