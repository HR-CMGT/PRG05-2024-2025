#!/bin/bash

echo -n "Please provide your git (SSH!) repo link: "
read -r git_repo_link

echo -n "Please provide your project machine name (lowercase/no spaces): "
read -r project_machine_name

echo -n "Please provide your project machine normal human name: "
read -r project_name

#clone, create .env and run build
mkdir ~/www/"$project_machine_name"
git clone "$git_repo_link" ~/www/"$project_machine_name"
cp ~/.env.example ~/www/"$project_machine_name"/.env
cd ~/www/"$project_machine_name" || exit
composer install --no-interaction --prefer-dist --optimize-autoloader
php artisan migrate --force
php artisan key:generate
npm install
npm run build

#replace .env contents
ip_address=$(hostname -I | awk '{print $1}')
sed -i "s/\[\[ip_address\]\]/$ip_address/g" ~/www/"$project_machine_name"/.env
sed -i "s/\[\[project_name\]\]/$project_name/g" ~/www/"$project_machine_name"/.env

#move build to production folder
sudo mkdir -p /var/www/production
sudo cp -R ~/www/"$project_machine_name"/. /var/www/production
sudo rm -rf /var/www/production/.git
cd /var/www/production && sudo php artisan storage:link

#fix rights for folders/files
sudo chown -R www-data:www-data /var/www/production
sudo find /var/www/production -type d -exec chmod 775 {} \;
sudo find /var/www/production -type f -exec chmod 664 {} \;
sudo chmod -R 775 /var/www/production/storage
sudo chmod -R 775 /var/www/production/bootstrap/cache

#create nginx conf for new website (and unlink default conf)
sudo cp ~/nginx.conf /etc/nginx/sites-available/"$project_machine_name"
sudo ln -s /etc/nginx/sites-available/"$project_machine_name" /etc/nginx/sites-enabled/
sudo unlink /etc/nginx/sites-enabled/default

#restart php-fpm and nginx
sudo service php8.3-fpm restart
sudo service nginx restart
